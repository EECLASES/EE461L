package observer2;

import javax.swing.*;
import java.awt.*;

public class ComplementaryColorPanel extends ColorPanel {

    public ComplementaryColorPanel(Color initialColor) {
    	super(initialColor);
    }

    @Override
    public void Update(Color newColor, Color complementaryColor) {
    	super.setColor(complementaryColor);
    }

 
}