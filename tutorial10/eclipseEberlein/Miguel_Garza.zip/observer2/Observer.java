package observer2;

import java.awt.Color;

public interface Observer {
	


	void Update(Color newColor, Color complementaryColor);
	
	
}
