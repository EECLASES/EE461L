package observer3;

import java.awt.Color;

public interface Observer {
	



	void Update(Color color);
	
	
}
